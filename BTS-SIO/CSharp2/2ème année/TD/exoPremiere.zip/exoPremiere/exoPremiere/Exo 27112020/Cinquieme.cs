﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo_27112020
{
    class Cinquieme : Premiere
    {
        public Cinquieme()
        {
            Console.WriteLine("constructeur de Cinquieme");
        }
    }
}
