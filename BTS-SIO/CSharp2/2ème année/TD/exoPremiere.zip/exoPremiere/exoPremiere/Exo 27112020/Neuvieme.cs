﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo_27112020
{
    class Neuvieme : Premiere
    {
        public Neuvieme(int i)
        {
            Console.WriteLine("premier constructeur de Neuvieme");
        }
        public Neuvieme(bool b)
        {
            Console.WriteLine("second constructeur de Neuvieme");
        }
    }

}
