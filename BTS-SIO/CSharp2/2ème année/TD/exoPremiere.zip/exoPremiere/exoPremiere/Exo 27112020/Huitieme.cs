﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo_27112020
{
    class Huitieme : Septieme
    {
        public Huitieme(int i)
            :base(i)
        {
            Console.WriteLine("constructeur de Huitieme");
        }
    }
}
