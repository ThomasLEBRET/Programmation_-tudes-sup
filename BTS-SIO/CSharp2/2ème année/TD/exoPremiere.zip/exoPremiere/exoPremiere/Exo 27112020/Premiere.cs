﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo_27112020
{
    class Premiere
    {
        public Premiere()
        {
            Console.WriteLine("constructeur de Premiere");
        }
    }
}
