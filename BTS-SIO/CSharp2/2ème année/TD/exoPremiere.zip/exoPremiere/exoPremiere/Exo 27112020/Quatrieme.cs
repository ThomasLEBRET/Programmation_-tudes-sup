﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo_27112020
{
    class Quatrieme : Troisieme{
        public Quatrieme(double d)
            :base(14)
        {
            Console.WriteLine("constructeur de Quatrieme");
        }
    }
}
